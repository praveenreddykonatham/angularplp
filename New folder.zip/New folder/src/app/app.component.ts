import { ProductServiceService } from './service/product-service.service';
import { Component, OnInit } from '@angular/core';
import { Login } from './../app/model/login.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
 title = 'capstore';

 ngOnInit() {}
 loginModel = new Login('', '');
 constructor(private ProductService : ProductServiceService) {}
  onSubmit() {
    console.log("Submitted");
    console.log(this.loginModel.loginName);
    console.log(this.loginModel.password);
    if (
      this.loginModel.loginName.length >= 4 &&
      this.loginModel.password.length >= 4
    ) {
     alert("password is saved in database")
    }
    else {
      alert("invalid login, try again!");
    }
  }
}




