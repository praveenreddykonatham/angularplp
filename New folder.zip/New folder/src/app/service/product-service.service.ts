import { Login } from './../model/login.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {

  baseUrl:string="http://localhost:8099";

  constructor(private http:HttpClient) { }
  get Login()
  {
    return this.http.get<Login[]>(this.baseUrl+'/encodes',login);
  }
}
